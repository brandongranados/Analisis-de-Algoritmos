public class quicksort{
    public static void main (String args[])
    {
        int arreglo[] = {10,8,5,7,1,3,6,2,9,4};
        int tam = arreglo.length-1;
        imprime(arreglo);
        qs(arreglo, 0, tam);
        imprime(arreglo);
        return;
    }
    private static void imprime(int imp[])
    {
        for(int i=0; i<imp.length; i++)
            System.out.println(imp[i]);
        return;
    }
    private static void qs(int vector[], int inf, int sup)
    {
        int izq, der, pivote, aux;
        izq = inf;
        der = sup;
        pivote = vector[(izq + der)/2];
        do
        {
            while((vector[izq] < pivote) && (izq < sup))
                izq++;
            while((vector[der] > pivote) && (der > inf))
                der--;
            if(izq <= der)
            {
                aux = vector[izq];
                vector[izq] = vector[der];
                vector[der] = aux;
                izq++;
                der++;
            }
        }while(izq <= der);
        if(inf < der)
            qs(vector, inf, der);
        if(izq < sup)
            qs(vector, izq, sup);
        return;
    }
}